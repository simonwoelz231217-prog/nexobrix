import asyncio
import datetime
import json
import math
import os
import random
import struct
import sys
import pygame

# Pygame & Audio initialisieren
pygame.init()
pygame.font.init()

try:
    pygame.mixer.init(frequency=44100, size=-16, channels=2)
    AUDIO_AVAILABLE = True
except Exception:
    AUDIO_AVAILABLE = False


def create_sound(freq, duration, wave_type="sine", volume=0.2):
    if not AUDIO_AVAILABLE:
        return None
    sample_rate = 44100
    n_samples = int(sample_rate * duration)
    buf = bytearray()
    for i in range(n_samples):
        t = i / sample_rate
        decay = 1.0 - (i / n_samples)
        if wave_type == "sine":
            val = math.sin(2 * math.pi * freq * t)
        elif wave_type == "square":
            val = 0.4 if math.sin(2 * math.pi * freq * t) > 0 else -0.4
        scaled = int(32767 * val * decay * volume)
        buf.extend(struct.pack("<h", max(-32768, min(32767, scaled))))
    return pygame.mixer.Sound(bytes(buf))


def play_sound_safe(snd):
    if AUDIO_AVAILABLE and snd is not None:
        try:
            snd.play()
        except Exception:
            pass


snd_place = create_sound(350, 0.06, "sine", 0.2)
snd_clear = create_sound(700, 0.15, "sine", 0.3)
snd_combo = create_sound(1050, 0.25, "square", 0.25)
snd_levelup = create_sound(880, 0.35, "sine", 0.4)
snd_bomb = create_sound(120, 0.35, "square", 0.4)
snd_gameover = create_sound(180, 0.4, "square", 0.3)

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 1300
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("NexoBrix")

clock = pygame.time.Clock()

# Schriftarten
font_score = pygame.font.SysFont("Arial", 19, bold=True)
font_title = pygame.font.SysFont("Arial", 25, bold=True)
font_combo = pygame.font.SysFont("Impact", 56, italic=True)
font_float = pygame.font.SysFont("Arial", 28, bold=True)
font_modal = pygame.font.SysFont("Arial", 40, bold=True)

# Static Text Renderings
TXT_TNT_SMALL = font_score.render("TNT", True, (255, 255, 255))

# Raster-Einstellungen
GRID_SIZE = 8
CELL_SIZE = 65
GAP = 6
BASE_OFFSET_X = 19
BASE_OFFSET_Y = 165

ROW_BEAM_W = GRID_SIZE * (CELL_SIZE + GAP) + 14
ROW_BEAM_H = CELL_SIZE + 4
COL_BEAM_W = CELL_SIZE + 4
COL_BEAM_H = GRID_SIZE * (CELL_SIZE + GAP) + 16

row_beam_surf = pygame.Surface((ROW_BEAM_W, ROW_BEAM_H), pygame.SRCALPHA)
col_beam_surf = pygame.Surface((COL_BEAM_W, COL_BEAM_H), pygame.SRCALPHA)
shine_surf = pygame.Surface((GRID_SIZE * (CELL_SIZE + GAP), GRID_SIZE * (CELL_SIZE + GAP)), pygame.SRCALPHA)

# Warme Holztöne für Standard-Blöcke (Eiche, Nussbaum, Mahagoni, Kiefer, Buche, Teak)
WOOD_BLOCK_COLORS = [
    (198, 142, 85),   # Eiche (Warmes Hellbraun)
    (132, 80, 42),    # Nussbaum (Mittelbraun)
    (165, 95, 45),    # Mahagoni-Touch (Rötliches Holz)
    (222, 178, 122),  # Kiefer (Helles Naturholz)
    (185, 125, 75),   # Buche (Warmes Rotbraun)
    (110, 62, 28),    # Dunkles Edelholz
]

# WOOD & BEIGE THEME
THEMES = [
    {
        "name": "Natural Wood",
        "bg": (212, 198, 180),           # Dunkel-Beige Hintergrund
        "grid_empty": (242, 234, 220),   # Helles Creme/Birke für leere Kästchen
        "filled": (110, 62, 28),          # Dunkelholz Akzent
        "text": (55, 38, 22),            # Tiefbrauner Text
        "card_bg": (253, 249, 242),       # Helles Elfenbein
        "obstacle": (150, 135, 118),
    }
]
current_theme_idx = 0

GAME_MODES = ["CLASSIC", "ZEIT"]
current_mode_idx = 0

BASE_SHAPES = [
    ([(0, 0)], "normal"),
    ([(0, 0), (1, 0)], "normal"),
    ([(0, 0), (0, 1)], "normal"),
    ([(0, 0), (1, 0), (2, 0)], "normal"),
    ([(0, 0), (0, 1), (0, 2)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (3, 0)], "normal"),
    ([(0, 0), (0, 1), (0, 2), (0, 3)], "normal"),
    ([(0, 0), (1, 0), (0, 1), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (0, 2), (1, 2), (2, 2)], "normal"),
    ([(0, 0), (0, 1), (0, 2), (1, 2)], "normal"),
    ([(1, 0), (1, 1), (1, 2), (0, 2)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (1, 1), (2, 1)], "normal"),
    ([(1, 0), (2, 0), (0, 1), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (0, 1)], "normal"),
]

COMBO_ANNOUNCEMENTS = ["GOOD!", "GREAT!", "SMOOTH!", "UNSTOPPABLE!", "FEVER!"]


def generate_random_block():
    shape, stype = random.choice(BASE_SHAPES)
    color = random.choice(WOOD_BLOCK_COLORS)

    rnd = random.random()
    if rnd < 0.06:
        stype = "ice2"
        color = (56, 189, 248)
    elif rnd < 0.11:
        stype = "gold"
        color = (234, 179, 8)
    elif rnd < 0.15:
        stype = "magnet"
        color = (168, 85, 247)

    return (shape, color, stype)


def rotate_shape_data(shape_data):
    shape, color, stype = shape_data
    rotated = [(-y, x) for x, y in shape]
    min_x = min(x for x, y in rotated)
    min_y = min(y for x, y in rotated)
    normalized = [(x - min_x, y - min_y) for x, y in rotated]
    return (normalized, color, stype)


def get_shape_dimensions(shape):
    max_x = max(x for x, y in shape) + 1
    max_y = max(y for x, y in shape) + 1
    return max_x, max_y


def load_game_data():
    hs, hsz, c, ld = 0, 0, 150, ""
    if sys.platform == "emscripten":
        try:
            import platform

            val = platform.window.localStorage.getItem("block_puzzle_save")
            if val:
                data = json.loads(str(val))
                hs = data.get("highscore", 0)
                hsz = data.get("highscore_zeit", 0)
                c = data.get("coins", 150)
                ld = data.get("last_daily", "")
                return hs, hsz, c, ld
        except Exception:
            pass

    if os.path.exists("highscore.json"):
        try:
            with open("highscore.json", "r") as f:
                data = json.load(f)
                hs = data.get("highscore", 0)
                hsz = data.get("highscore_zeit", 0)
                c = data.get("coins", 150)
                ld = data.get("last_daily", "")
        except Exception:
            pass
    return hs, hsz, c, ld


def save_game_data(hs, hsz, c, ld):
    payload = {"highscore": hs, "highscore_zeit": hsz, "coins": c, "last_daily": ld}
    if sys.platform == "emscripten":
        try:
            import platform

            platform.window.localStorage.setItem(
                "block_puzzle_save", json.dumps(payload)
            )
        except Exception:
            pass
    try:
        with open("highscore.json", "w") as f:
            json.dump(payload, f)
    except Exception:
        pass


grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
score = 0
highscore, highscore_zeit, coins, last_daily_date = load_game_data()
level = 1
level_target = 500

time_left = 35.0
combo_gauge = 0.0
fever_active = False
fever_timer = 0.0
shine_progress = -1.0

game_over = False
level_complete = False

today_str = datetime.date.today().isoformat()
show_daily_reward_modal = last_daily_date != today_str

particles = []
floating_texts = []
clearing_beams = []

combo_announcement = None
shake_intensity = 0

MAX_PARTICLES = 40

SLOT_RECTS = [
    pygame.Rect(15, 755, 180, 210),
    pygame.Rect(210, 755, 180, 210),
    pygame.Rect(405, 755, 180, 210),
]
current_blocks = [generate_random_block() for _ in range(3)]

selected_block_idx = None
block_x, block_y = 0, 0
dragging = False
rotate_mode_active = False

mode_button_rect = pygame.Rect(420, 40, 135, 40)
claim_daily_btn_rect = pygame.Rect(180, 620, 240, 65)
next_level_button_rect = pygame.Rect(180, 610, 240, 65)
restart_button_rect = pygame.Rect(180, 610, 240, 65)

# Edle Holz-Farbe für Booster-Buttons
WOOD_BOOSTER_COLOR = (105, 58, 26)
btn_rotate_rect = pygame.Rect(15, 1050, 132, 175)
btn_clear_rows_rect = pygame.Rect(161, 1050, 132, 175)
btn_buy_tnt_rect = pygame.Rect(307, 1050, 132, 175)
btn_buy_laser_rect = pygame.Rect(453, 1050, 132, 175)


def reset_game():
    global grid, score, level, level_target, current_blocks, game_over, level_complete
    global selected_block_idx, dragging, particles, floating_texts, shake_intensity, rotate_mode_active
    global time_left, combo_gauge, fever_active, fever_timer, shine_progress

    grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
    score = 0
    level = 1
    time_left = 35.0
    combo_gauge = 0.0
    fever_active = False
    fever_timer = 0.0
    shine_progress = -1.0

    level_target = 500
    particles.clear()
    floating_texts.clear()
    shake_intensity = 0
    rotate_mode_active = False
    current_blocks = [generate_random_block() for _ in range(3)]
    game_over = False
    level_complete = False
    selected_block_idx = None
    dragging = False


def start_next_level():
    global grid, level, level_target, current_blocks, level_complete, particles, floating_texts, coins, rotate_mode_active, shine_progress
    level += 1
    level_target += level * 500
    coins += 100
    save_game_data(highscore, highscore_zeit, coins, last_daily_date)

    grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
    particles.clear()
    floating_texts.clear()
    rotate_mode_active = False
    shine_progress = -1.0
    current_blocks = [generate_random_block() for _ in range(3)]
    level_complete = False


def claim_daily_reward():
    global coins, last_daily_date, show_daily_reward_modal
    coins += 200
    last_daily_date = today_str
    save_game_data(highscore, highscore_zeit, coins, last_daily_date)
    show_daily_reward_modal = False
    add_floating_text("+200 Coins Tages-Bonus!", SCREEN_WIDTH // 2, 550, (217, 119, 6))


def toggle_rotate_mode():
    global rotate_mode_active, coins
    if coins < 50:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 720, (220, 38, 38))
        rotate_mode_active = False
        return

    rotate_mode_active = not rotate_mode_active
    if rotate_mode_active:
        add_floating_text("Tippe auf einen Block!", SCREEN_WIDTH // 2, 720, (180, 100, 40))


def execute_single_block_rotation(idx):
    global coins, current_blocks, rotate_mode_active
    if current_blocks[idx] is None:
        return

    coins -= 50
    save_game_data(highscore, highscore_zeit, coins, last_daily_date)
    current_blocks[idx] = rotate_shape_data(current_blocks[idx])
    rotate_mode_active = False

    slot_r = SLOT_RECTS[idx]
    add_floating_text("GEDREHT!", slot_r.centerx, slot_r.top - 15, (180, 100, 40))
    play_sound_safe(snd_place)


def booster_clear_2_rows():
    global coins, score, shake_intensity, rotate_mode_active
    rotate_mode_active = False

    if coins < 100:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 720, (220, 38, 38))
        return

    row_counts = [(r, sum(1 for c in range(GRID_SIZE) if grid[r][c] is not None)) for r in range(GRID_SIZE)]
    row_counts = [x for x in row_counts if x[1] > 0]

    if not row_counts:
        add_floating_text("Spielfeld ist leer!", SCREEN_WIDTH // 2, 720, (217, 119, 6))
        return

    coins -= 100
    save_game_data(highscore, highscore_zeit, coins, last_daily_date)

    row_counts.sort(key=lambda x: x[1], reverse=True)
    rows_to_clear = [r for r, count in row_counts[:2]]

    for r in rows_to_clear:
        add_clearing_beam('row', r)
        for c in range(GRID_SIZE):
            if grid[r][c] is not None:
                grid[r][c] = None
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=3)

    shake_intensity = 8
    score += 200
    trigger_combo_announcement("BOOSTER!", (217, 119, 6))
    play_sound_safe(snd_combo)


def buy_special_block(stype, cost):
    global coins, current_blocks, rotate_mode_active
    rotate_mode_active = False

    if coins < cost:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 720, (220, 38, 38))
        return

    free_idx = None
    for i in range(3):
        if current_blocks[i] is None:
            free_idx = i
            break

    if free_idx is None:
        free_idx = 0

    coins -= cost
    save_game_data(highscore, highscore_zeit, coins, last_daily_date)

    if stype == "bomb":
        current_blocks[free_idx] = ([(0, 0)], (220, 38, 38), "bomb")
        add_floating_text("TNT GEKAUFT!", SCREEN_WIDTH // 2, 720, (220, 38, 38))
    elif stype == "laser":
        current_blocks[free_idx] = ([(0, 0)], (2, 132, 199), "laser")
        add_floating_text("LASER GEKAUFT!", SCREEN_WIDTH // 2, 720, (2, 132, 199))

    play_sound_safe(snd_place)


def add_floating_text(text, x, y, color):
    surf = font_float.render(text, True, color)
    floating_texts.append({"surf": surf, "x": x, "y": y, "lifetime": 35})


def trigger_combo_announcement(text, color=(217, 119, 6)):
    global combo_announcement
    txt_surf = font_combo.render(text, True, color)
    combo_announcement = {"surf": txt_surf, "lifetime": 40}


def add_clearing_beam(btype, index, color=(198, 142, 85)):
    clearing_beams.append({"type": btype, "index": index, "color": color, "lifetime": 10, "max_life": 10})


def trigger_magnet_clearing(target_color):
    global score, coins, shake_intensity
    cleared_count = 0
    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            if grid[r][c] is not None and grid[r][c][0] == target_color:
                grid[r][c] = None
                cleared_count += 1
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=4, custom_colors=[(168, 85, 247), (255, 255, 255)])

    if cleared_count > 0:
        pts = cleared_count * 60
        score += pts
        shake_intensity = 10
        add_floating_text(f"MAGNET! +{pts}", SCREEN_WIDTH // 2, 420, (168, 85, 247))
        play_sound_safe(snd_combo)


def update_and_draw_effects(offset_x, offset_y):
    global combo_announcement, shine_progress

    if shine_progress >= 0.0:
        shine_progress += 0.03
        if shine_progress > 1.4:
            shine_progress = -1.0
        else:
            grid_w = GRID_SIZE * (CELL_SIZE + GAP)
            shine_surf.fill((0, 0, 0, 0))
            pos_x = int(grid_w * shine_progress)
            poly = [(pos_x - 120, 0), (pos_x, 0), (pos_x - 60, grid_w), (pos_x - 180, grid_w)]
            pygame.draw.polygon(shine_surf, (255, 255, 255, 120), poly)
            screen.blit(shine_surf, (BASE_OFFSET_X + offset_x, BASE_OFFSET_Y + offset_y))

    for beam in clearing_beams[:]:
        beam["lifetime"] -= 1
        if beam["lifetime"] <= 0:
            clearing_beams.remove(beam)
        else:
            alpha = int(180 * (beam["lifetime"] / beam["max_life"]))
            if beam["type"] == "row":
                r = beam["index"]
                y = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + offset_y - 2
                row_beam_surf.fill((0, 0, 0, 0))
                pygame.draw.rect(row_beam_surf, (*beam["color"], alpha), (0, 0, ROW_BEAM_W, ROW_BEAM_H), border_radius=8)
                screen.blit(row_beam_surf, (BASE_OFFSET_X - 10, y))
            else:
                c = beam["index"]
                x = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + offset_x - 2
                col_beam_surf.fill((0, 0, 0, 0))
                pygame.draw.rect(col_beam_surf, (*beam["color"], alpha), (0, 0, COL_BEAM_W, COL_BEAM_H), border_radius=8)
                screen.blit(col_beam_surf, (x, BASE_OFFSET_Y - 10))

    for p in particles[:]:
        p["x"] += p["vx"]
        p["y"] += p["vy"]
        p["radius"] -= 0.25
        p["lifetime"] -= 1

        if p["lifetime"] <= 0 or p["radius"] <= 0:
            particles.remove(p)
        else:
            pygame.draw.circle(screen, p["color"], (int(p["x"] + offset_x), int(p["y"] + offset_y)), int(p["radius"]))

    for ft in floating_texts[:]:
        ft["y"] -= 1.3
        ft["lifetime"] -= 1

        if ft["lifetime"] <= 0:
            floating_texts.remove(ft)
        else:
            s = ft["surf"]
            screen.blit(s, (ft["x"] + offset_x - s.get_width() // 2, ft["y"] + offset_y))

    if combo_announcement:
        ca = combo_announcement
        ca["lifetime"] -= 1
        if ca["lifetime"] <= 0:
            combo_announcement = None
        else:
            s = ca["surf"]
            cx = SCREEN_WIDTH // 2
            cy = 135
            screen.blit(s, (cx - s.get_width() // 2, cy - s.get_height() // 2))


def spawn_particles(x, y, count=3, custom_colors=None):
    if len(particles) >= MAX_PARTICLES:
        return

    colors = custom_colors or [(198, 142, 85), (222, 178, 122), (132, 80, 42)]
    spawn_count = min(count, MAX_PARTICLES - len(particles))
    for _ in range(spawn_count):
        particles.append(
            {
                "x": x,
                "y": y,
                "vx": random.uniform(-4, 4),
                "vy": random.uniform(-4, 4),
                "radius": random.randint(3, 5),
                "lifetime": random.randint(12, 20),
                "color": random.choice(colors),
            }
        )


def draw_vector_icon(surface, itype, cx, cy, color=(255, 245, 230)):
    if itype == "rotate":
        pygame.draw.arc(surface, color, (cx - 16, cy - 16, 32, 32), 0.5, 5.2, 3)
        pygame.draw.polygon(surface, color, [(cx + 10, cy - 14), (cx + 18, cy - 4), (cx + 6, cy - 2)])
    elif itype == "2rows":
        pygame.draw.rect(surface, (240, 200, 150), (cx - 18, cy - 12, 36, 8), border_radius=3)
        pygame.draw.rect(surface, (240, 200, 150), (cx - 18, cy + 4, 36, 8), border_radius=3)
    elif itype == "tnt":
        pygame.draw.rect(surface, (220, 50, 50), (cx - 18, cy - 15, 36, 30), border_radius=5)
        surface.blit(TXT_TNT_SMALL, (cx - TXT_TNT_SMALL.get_width() // 2, cy - TXT_TNT_SMALL.get_height() // 2))
    elif itype == "laser":
        pts = [(cx + 3, cy - 16), (cx - 10, cy + 1), (cx - 2, cy + 1), (cx - 6, cy + 16), (cx + 10, cy - 1), (cx + 2, cy - 1)]
        pygame.draw.polygon(surface, (250, 210, 100), pts)
    elif itype == "ice":
        pygame.draw.line(surface, (255, 255, 255), (cx - 12, cy), (cx + 12, cy), 3)
        pygame.draw.line(surface, (255, 255, 255), (cx, cy - 12), (cx, cy + 12), 3)
        pygame.draw.line(surface, (255, 255, 255), (cx - 8, cy - 8), (cx + 8, cy + 8), 2)
        pygame.draw.line(surface, (255, 255, 255), (cx - 8, cy + 8), (cx + 8, cy - 8), 2)
    elif itype == "gold":
        pygame.draw.circle(surface, (250, 204, 21), (cx, cy), 13)
        pygame.draw.circle(surface, (202, 138, 4), (cx, cy), 13, 2)
        pygame.draw.circle(surface, (254, 240, 138), (cx, cy), 7)
    elif itype == "magnet":
        pygame.draw.arc(surface, (239, 68, 68), (cx - 12, cy - 12, 24, 24), 3.14, 6.28, 5)
        pygame.draw.rect(surface, (239, 68, 68), (cx - 12, cy - 4, 5, 12))
        pygame.draw.rect(surface, (239, 68, 68), (cx + 7, cy - 4, 5, 12))
        pygame.draw.rect(surface, (241, 245, 249), (cx - 12, cy + 4, 5, 4))
        pygame.draw.rect(surface, (241, 245, 249), (cx + 7, cy + 4, 5, 4))


def draw_beveled_block(surface, x, y, size, color, stype="normal"):
    base_color = color
    hi_color = (min(255, color[0] + 40), min(255, color[1] + 35), min(255, color[2] + 30))
    sh_color = (max(0, color[0] - 45), max(0, color[1] - 40), max(0, color[2] - 35))

    if stype == "ice2" or stype == "ice1":
        base_color = (56, 189, 248) if stype == "ice2" else (125, 211, 252)
        hi_color = (224, 242, 254)
        sh_color = (2, 132, 199)
    elif stype == "gold":
        base_color = (234, 179, 8)
        hi_color = (254, 240, 138)
        sh_color = (161, 98, 7)
    elif stype == "magnet":
        base_color = (168, 85, 247)
        hi_color = (233, 213, 255)
        sh_color = (126, 34, 206)

    rect = pygame.Rect(x, y, size, size)
    pygame.draw.rect(surface, base_color, rect, border_radius=9)

    # Holzmaserungs-Linien zeichnen
    if stype not in ["bomb", "laser", "gold", "magnet"]:
        grain_color = (max(0, base_color[0] - 25), max(0, base_color[1] - 20), max(0, base_color[2] - 15))
        pygame.draw.line(surface, grain_color, (x + 6, y + int(size * 0.3)), (x + size - 8, y + int(size * 0.35)), 1)
        pygame.draw.line(surface, grain_color, (x + 8, y + int(size * 0.65)), (x + size - 6, y + int(size * 0.6)), 1)

    # Bevel Kanten
    pygame.draw.line(surface, hi_color, (x + 3, y + 3), (x + size - 4, y + 3), 2)
    pygame.draw.line(surface, hi_color, (x + 3, y + 3), (x + 3, y + size - 4), 2)

    pygame.draw.line(surface, sh_color, (x + 3, y + size - 3), (x + size - 3, y + size - 3), 2)
    pygame.draw.line(surface, sh_color, (x + size - 3, y + 3), (x + size - 3, y + size - 3), 2)

    cx, cy = x + size // 2, y + size // 2
    if stype == "bomb":
        draw_vector_icon(surface, "tnt", cx, cy)
    elif stype == "laser":
        draw_vector_icon(surface, "laser", cx, cy)
    elif stype == "ice2" or stype == "ice1":
        draw_vector_icon(surface, "ice", cx, cy)
    elif stype == "gold":
        draw_vector_icon(surface, "gold", cx, cy)
    elif stype == "magnet":
        draw_vector_icon(surface, "magnet", cx, cy)


def draw_grid(offset_x, offset_y):
    theme = THEMES[current_theme_idx]

    # Elfenbein Top Card
    card_rect = pygame.Rect(15 + offset_x, 25 + offset_y, 570, 110)
    pygame.draw.rect(screen, theme["card_bg"], card_rect, border_radius=20)
    pygame.draw.rect(screen, (195, 182, 165), card_rect, width=2, border_radius=20)

    is_zeit = GAME_MODES[current_mode_idx] == "ZEIT"

    title_label = "ZEITMODUS" if is_zeit else f"LEVEL {level}"
    lvl_txt = font_title.render(title_label, True, theme["filled"])
    screen.blit(lvl_txt, (30 + offset_x, 38 + offset_y))

    pygame.draw.circle(screen, (245, 158, 11), (205 + offset_x, 52 + offset_y), 13)
    pygame.draw.circle(screen, (252, 211, 77), (205 + offset_x, 52 + offset_y), 9)
    coin_txt = font_title.render(f"{coins}", True, (217, 119, 6))
    screen.blit(coin_txt, (226 + offset_x, 38 + offset_y))

    # Edler Holz-Modus-Button
    pygame.draw.rect(screen, (132, 80, 42), mode_button_rect, border_radius=12)
    pygame.draw.rect(screen, (85, 48, 22), mode_button_rect, width=2, border_radius=12)
    btn_m_txt = font_score.render(f"{GAME_MODES[current_mode_idx]}", True, (255, 245, 230))
    screen.blit(
        btn_m_txt,
        (
            mode_button_rect.centerx - btn_m_txt.get_width() // 2,
            mode_button_rect.centery - btn_m_txt.get_height() // 2,
        ),
    )

    cur_high = highscore_zeit if is_zeit else highscore
    sc_str = f"Punkte: {score}   |   Rekord: {cur_high}" if is_zeit else f"Punkte: {score} / {level_target}   |   Rekord: {cur_high}"
    sc_txt = font_score.render(sc_str, True, theme["text"])
    screen.blit(sc_txt, (30 + offset_x, 88 + offset_y))

    if is_zeit:
        timer_bg = pygame.Rect(15 + offset_x, 142 + offset_y, 270, 12)
        pygame.draw.rect(screen, (195, 182, 165), timer_bg, border_radius=6)
        time_ratio = max(0.0, min(1.0, time_left / 35.0))
        timer_fg = pygame.Rect(15 + offset_x, 142 + offset_y, int(270 * time_ratio), 12)
        pygame.draw.rect(screen, (220, 38, 38) if time_left < 8 else (132, 80, 42), timer_fg, border_radius=6)

        combo_bg = pygame.Rect(315 + offset_x, 142 + offset_y, 270, 12)
        pygame.draw.rect(screen, (195, 182, 165), combo_bg, border_radius=6)
        combo_ratio = max(0.0, min(1.0, combo_gauge / 100.0))
        combo_fg = pygame.Rect(315 + offset_x, 142 + offset_y, int(270 * combo_ratio), 12)
        pygame.draw.rect(screen, (245, 158, 11) if fever_active else (168, 85, 247), combo_fg, border_radius=6)

    # Spielfeld mit hellen Creme/Birke-Kästchen
    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            x = BASE_OFFSET_X + col * (CELL_SIZE + GAP) + offset_x
            y = BASE_OFFSET_Y + row * (CELL_SIZE + GAP) + offset_y

            cell_val = grid[row][col]
            if cell_val is None:
                pygame.draw.rect(screen, theme["grid_empty"], (x, y, CELL_SIZE, CELL_SIZE), border_radius=9)
            else:
                color, stype = cell_val
                draw_beveled_block(screen, x, y, CELL_SIZE, color, stype)


def draw_slot_cards(offset_x, offset_y):
    theme = THEMES[current_theme_idx]
    for idx, slot_rect in enumerate(SLOT_RECTS):
        r = slot_rect.move(offset_x, offset_y)
        pygame.draw.rect(screen, theme["card_bg"], r, border_radius=20)
        pygame.draw.rect(screen, (195, 182, 165), r, width=2, border_radius=20)

        if rotate_mode_active and current_blocks[idx] is not None:
            pygame.draw.rect(screen, (180, 100, 40), r, width=3, border_radius=20)

        shape_data = current_blocks[idx]
        if shape_data is not None and idx != selected_block_idx:
            w, h = get_shape_dimensions(shape_data[0])
            block_w_px = w * (CELL_SIZE * 0.65 + GAP * 0.65)
            block_h_px = h * (CELL_SIZE * 0.65 + GAP * 0.65)

            center_x = r.centerx - block_w_px // 2
            center_y = r.centery - block_h_px // 2
            draw_block(shape_data, center_x, center_y, scale=0.65)


def draw_coin_price(amount, center_x, top_y):
    pygame.draw.circle(screen, (245, 158, 11), (center_x - 18, top_y + 10), 8)
    pygame.draw.circle(screen, (252, 211, 77), (center_x - 18, top_y + 10), 5)
    c_txt = font_score.render(str(amount), True, (252, 211, 77))
    screen.blit(c_txt, (center_x - 6, top_y))


def draw_booster_buttons():
    active_color = (180, 100, 40) if rotate_mode_active else WOOD_BOOSTER_COLOR

    for rect, itype, price in [
        (btn_rotate_rect, "rotate", 50),
        (btn_clear_rows_rect, "2rows", 100),
        (btn_buy_tnt_rect, "tnt", 120),
        (btn_buy_laser_rect, "laser", 120),
    ]:
        col = active_color if rect == btn_rotate_rect else WOOD_BOOSTER_COLOR
        pygame.draw.rect(screen, col, rect, border_radius=18)
        pygame.draw.rect(screen, (65, 35, 15), rect, width=3, border_radius=18)

        # Holzmaserung auf den Booster-Tasten
        pygame.draw.line(screen, (85, 45, 18), (rect.left + 10, rect.top + 25), (rect.right - 10, rect.top + 28), 2)
        pygame.draw.line(screen, (85, 45, 18), (rect.left + 12, rect.top + 80), (rect.right - 12, rect.top + 77), 2)

        draw_vector_icon(screen, itype, rect.centerx, rect.top + 45)
        draw_coin_price(price, rect.centerx, rect.top + 100)


def draw_ghost_preview(shape, grid_col, grid_row, offset_x, offset_y):
    if not can_place(shape, grid_col, grid_row):
        return

    ghost_surface = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
    pygame.draw.rect(ghost_surface, (132, 80, 42, 80), (0, 0, CELL_SIZE, CELL_SIZE), border_radius=9)

    for bx, by in shape:
        c, r = grid_col + bx, grid_row + by
        if 0 <= c < GRID_SIZE and 0 <= r < GRID_SIZE:
            gx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + offset_x
            gy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + offset_y
            screen.blit(ghost_surface, (gx, gy))


def draw_block(shape_data, pos_x, pos_y, scale=1.0):
    shape, color, stype = shape_data
    size = int(CELL_SIZE * scale)
    gap = int(GAP * scale)

    for bx, by in shape:
        x = pos_x + bx * (size + gap)
        y = pos_y + by * (size + gap)
        draw_beveled_block(screen, x, y, size, color, stype)


def can_place(shape, grid_col, grid_row):
    for bx, by in shape:
        c, r = grid_col + bx, grid_row + by
        if c < 0 or c >= GRID_SIZE or r < 0 or r >= GRID_SIZE:
            return False
        if grid[r][c] is not None:
            return False
    return True


def place_block(shape_data, grid_col, grid_row):
    shape, color, stype = shape_data
    for bx, by in shape:
        grid[grid_row + by][grid_col + bx] = (color, stype)


def trigger_bomb_explosion(center_col, center_row):
    global score, shake_intensity
    cleared_count = 0
    explosion_colors = [(239, 68, 68), (245, 158, 11), (255, 255, 255)]

    for r in range(center_row - 1, center_row + 2):
        for c in range(center_col - 1, center_col + 2):
            if 0 <= r < GRID_SIZE and 0 <= c < GRID_SIZE:
                if grid[r][c] is not None:
                    grid[r][c] = None
                    cleared_count += 1
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=3, custom_colors=explosion_colors)

    score_gained = cleared_count * 50 + 200
    score += score_gained
    shake_intensity = 10
    center_x = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
    center_y = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP)
    add_floating_text(f"BOOM! +{score_gained}", center_x, center_y, (220, 38, 38))
    play_sound_safe(snd_bomb)


def trigger_laser_clearing(center_col, center_row):
    global score, shake_intensity
    laser_colors = [(250, 210, 100), (255, 255, 255)]

    add_clearing_beam('row', center_row, (250, 210, 100))
    add_clearing_beam('col', center_col, (250, 210, 100))

    for c in range(GRID_SIZE):
        grid[center_row][c] = None
        cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
        cy = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP) + CELL_SIZE // 2
        spawn_particles(cx, cy, count=2, custom_colors=laser_colors)

    for r in range(GRID_SIZE):
        grid[r][center_col] = None
        cx = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
        cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
        spawn_particles(cx, cy, count=2, custom_colors=laser_colors)

    score += 350
    shake_intensity = 8
    center_x = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
    center_y = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP)
    add_floating_text("LASER! +350", center_x, center_y, (180, 100, 40))
    play_sound_safe(snd_combo)


def clear_lines():
    global score, highscore, highscore_zeit, coins, shake_intensity, level_complete, time_left, combo_gauge, fever_active, shine_progress

    rows = [r for r in range(GRID_SIZE) if all(grid[r][c] is not None for c in range(GRID_SIZE))]
    cols = [c for c in range(GRID_SIZE) if all(grid[r][c] is not None for r in range(GRID_SIZE))]

    cleared = len(rows) + len(cols)
    is_zeit = GAME_MODES[current_mode_idx] == "ZEIT"

    if cleared > 0:
        multiplier = 2 if fever_active else 1
        pts = cleared * 100 * cleared * multiplier
        score += pts

        coins_gained = cleared * 15
        coins += coins_gained

        if is_zeit:
            time_left = min(40.0, time_left + cleared * 4.0)
            combo_gauge = min(100.0, combo_gauge + cleared * 25.0)
            if score > highscore_zeit:
                highscore_zeit = score
        else:
            if score > highscore:
                highscore = score

        save_game_data(highscore, highscore_zeit, coins, last_daily_date)
        shake_intensity = min(8, 4 * cleared)

        announcement_idx = min(cleared - 1, len(COMBO_ANNOUNCEMENTS) - 1)
        trigger_combo_announcement(COMBO_ANNOUNCEMENTS[announcement_idx])

        if cleared > 1:
            play_sound_safe(snd_combo)
        else:
            play_sound_safe(snd_clear)

    for r in rows:
        add_clearing_beam('row', r)
        for c in range(GRID_SIZE):
            cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
            cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2

            if grid[r][c] is not None:
                stype = grid[r][c][1]
                if stype == "ice2":
                    grid[r][c] = (grid[r][c][0], "ice1")
                    spawn_particles(cx, cy, count=4, custom_colors=[(125, 211, 252)])
                else:
                    if stype == "gold":
                        coins += 50
                        spawn_particles(cx, cy, count=6, custom_colors=[(250, 204, 21)])
                        add_floating_text("+50 Coins!", cx, cy, (217, 119, 6))
                    else:
                        spawn_particles(cx, cy, count=2)
                    grid[r][c] = None

    for c in cols:
        add_clearing_beam('col', c)
        for r in range(GRID_SIZE):
            if grid[r][c] is not None:
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                stype = grid[r][c][1]
                if stype == "ice2":
                    grid[r][c] = (grid[r][c][0], "ice1")
                    spawn_particles(cx, cy, count=4, custom_colors=[(125, 211, 252)])
                else:
                    if stype == "gold":
                        coins += 50
                        spawn_particles(cx, cy, count=6, custom_colors=[(250, 204, 21)])
                        add_floating_text("+50 Coins!", cx, cy, (217, 119, 6))
                    else:
                        spawn_particles(cx, cy, count=2)
                    grid[r][c] = None

    if cleared > 0:
        add_floating_text(f"+{pts}", SCREEN_WIDTH // 2, 420, (217, 119, 6))

    if not is_zeit and score >= level_target and not level_complete:
        level_complete = True
        shine_progress = 0.0
        play_sound_safe(snd_levelup)


def check_game_over():
    for shape_data in current_blocks:
        if shape_data is not None:
            shape = shape_data[0]
            for r in range(GRID_SIZE):
                for c in range(GRID_SIZE):
                    if can_place(shape, c, r):
                        return False
    return True


def draw_daily_reward_modal():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((30, 22, 15, 220))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(90, 430, 420, 330)
    pygame.draw.rect(screen, (253, 249, 242), modal_rect, border_radius=18)

    title_txt = font_modal.render("TAGES-BONUS!", True, (217, 119, 6))
    sub_txt = font_title.render("Danke fürs Wiederspielen!", True, (55, 38, 22))
    screen.blit(title_txt, (SCREEN_WIDTH // 2 - title_txt.get_width() // 2, 455))
    screen.blit(sub_txt, (SCREEN_WIDTH // 2 - sub_txt.get_width() // 2, 515))

    pygame.draw.circle(screen, (245, 158, 11), (SCREEN_WIDTH // 2 - 75, 585), 14)
    pygame.draw.circle(screen, (252, 211, 77), (SCREEN_WIDTH // 2 - 75, 585), 9)
    bonus_txt = font_modal.render("+200", True, (132, 80, 42))
    screen.blit(bonus_txt, (SCREEN_WIDTH // 2 - 50, 585 - bonus_txt.get_height() // 2))

    pygame.draw.rect(screen, (245, 158, 11), claim_daily_btn_rect, border_radius=25)
    btn_txt = font_title.render("Kassieren! 🎁", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            claim_daily_btn_rect.centerx - btn_txt.get_width() // 2,
            claim_daily_btn_rect.centery - btn_txt.get_height() // 2,
        ),
    )


def draw_level_complete_screen():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((30, 22, 15, 200))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(100, 420, 400, 350)
    pygame.draw.rect(screen, (253, 249, 242), modal_rect, border_radius=18)

    title_txt = font_modal.render("GESCHAFFT!", True, (132, 80, 42))
    sub_txt = font_title.render(f"Level {level} geschafft!", True, (55, 38, 22))
    bonus_txt = font_title.render("Belohnung: +100 Coins", True, (217, 119, 6))
    score_txt = font_score.render(f"Gesamtpunkte: {score}", True, (120, 105, 90))

    screen.blit(title_txt, (SCREEN_WIDTH // 2 - title_txt.get_width() // 2, 445))
    screen.blit(sub_txt, (SCREEN_WIDTH // 2 - sub_txt.get_width() // 2, 505))
    screen.blit(bonus_txt, (SCREEN_WIDTH // 2 - bonus_txt.get_width() // 2, 550))
    screen.blit(score_txt, (SCREEN_WIDTH // 2 - score_txt.get_width() // 2, 590))

    pygame.draw.rect(screen, (132, 80, 42), next_level_button_rect, border_radius=25)
    btn_txt = font_title.render("Nächstes Level ->", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            next_level_button_rect.centerx - btn_txt.get_width() // 2,
            next_level_button_rect.centery - btn_txt.get_height() // 2,
        ),
    )


def draw_game_over_screen():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((30, 22, 15, 210))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(100, 420, 400, 330)
    pygame.draw.rect(screen, (253, 249, 242), modal_rect, border_radius=18)

    go_text = font_modal.render("GAME OVER", True, (220, 38, 38))

    is_zeit = GAME_MODES[current_mode_idx] == "ZEIT"
    sub_str = f"Punkte: {score}" if is_zeit else f"Erreichtes Level: {level}"
    score_txt = font_title.render(sub_str, True, (55, 38, 22))

    cur_high = highscore_zeit if is_zeit else highscore
    detail_txt = font_score.render(f"Rekord: {cur_high}", True, (120, 105, 90))

    screen.blit(go_text, (SCREEN_WIDTH // 2 - go_text.get_width() // 2, 445))
    screen.blit(score_txt, (SCREEN_WIDTH // 2 - score_txt.get_width() // 2, 505))
    screen.blit(detail_txt, (SCREEN_WIDTH // 2 - detail_txt.get_width() // 2, 555))

    pygame.draw.rect(screen, (220, 38, 38), restart_button_rect, border_radius=25)
    btn_txt = font_title.render("Neustart", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            restart_button_rect.centerx - btn_txt.get_width() // 2,
            restart_button_rect.centery - btn_txt.get_height() // 2,
        ),
    )


async def main():
    global score, highscore, highscore_zeit, coins, shake_intensity, time_left, combo_gauge, fever_active, fever_timer
    global selected_block_idx, block_x, block_y, dragging, game_over, level_complete
    global current_mode_idx, current_blocks, level, rotate_mode_active

    running = True
    while running:
        dt = clock.tick(60) / 1000.0

        if GAME_MODES[current_mode_idx] == "ZEIT" and not game_over and not level_complete and not show_daily_reward_modal:
            time_left -= dt
            if time_left <= 0:
                time_left = 0
                game_over = True
                play_sound_safe(snd_gameover)

            if combo_gauge >= 100.0 and not fever_active:
                fever_active = True
                fever_timer = 6.0
                trigger_combo_announcement("FEVER MODE!", (245, 158, 11))

            if fever_active:
                fever_timer -= dt
                if fever_timer <= 0:
                    fever_active = False
                    combo_gauge = 0.0
            else:
                combo_gauge = max(0.0, combo_gauge - dt * 6.0)

        off_x, off_y = 0, 0
        if shake_intensity > 0:
            off_x = random.randint(-shake_intensity, shake_intensity)
            off_y = random.randint(-shake_intensity, shake_intensity)
            shake_intensity -= 1

        theme = THEMES[current_theme_idx]
        screen.fill(theme["bg"])

        draw_grid(off_x, off_y)
        draw_slot_cards(off_x, off_y)
        draw_booster_buttons()

        if (
            dragging
            and selected_block_idx is not None
            and not game_over
            and not level_complete
            and not show_daily_reward_modal
        ):
            shape = current_blocks[selected_block_idx][0]
            g_col = round((block_x - BASE_OFFSET_X) / (CELL_SIZE + GAP))
            g_row = round((block_y - BASE_OFFSET_Y) / (CELL_SIZE + GAP))
            draw_ghost_preview(shape, g_col, g_row, off_x, off_y)

        if (
            dragging
            and selected_block_idx is not None
            and not game_over
            and not level_complete
            and not show_daily_reward_modal
        ):
            draw_block(current_blocks[selected_block_idx], block_x, block_y, scale=1.0)

        update_and_draw_effects(off_x, off_y)

        if show_daily_reward_modal:
            draw_daily_reward_modal()
        elif level_complete:
            draw_level_complete_screen()
        elif game_over:
            draw_game_over_screen()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    reset_game()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if show_daily_reward_modal:
                    if claim_daily_btn_rect.collidepoint(mx, my):
                        claim_daily_reward()

                elif level_complete and next_level_button_rect.collidepoint(mx, my):
                    start_next_level()

                elif game_over and restart_button_rect.collidepoint(mx, my):
                    reset_game()

                elif not game_over and not level_complete:
                    if mode_button_rect.collidepoint(mx, my):
                        current_mode_idx = (current_mode_idx + 1) % len(GAME_MODES)
                        reset_game()

                    elif btn_rotate_rect.collidepoint(mx, my):
                        toggle_rotate_mode()

                    elif btn_clear_rows_rect.collidepoint(mx, my):
                        booster_clear_2_rows()

                    elif btn_buy_tnt_rect.collidepoint(mx, my):
                        buy_special_block("bomb", 120)

                    elif btn_buy_laser_rect.collidepoint(mx, my):
                        buy_special_block("laser", 120)

                    else:
                        slot_clicked = False
                        for idx, slot_rect in enumerate(SLOT_RECTS):
                            if slot_rect.collidepoint(mx, my):
                                if current_blocks[idx] is not None:
                                    slot_clicked = True
                                    if rotate_mode_active:
                                        execute_single_block_rotation(idx)
                                    else:
                                        selected_block_idx = idx
                                        dragging = True
                                        w, h = get_shape_dimensions(current_blocks[idx][0])
                                        block_x = mx - (w * CELL_SIZE) // 2
                                        block_y = my - (h * CELL_SIZE) - 90

                        if not slot_clicked and rotate_mode_active:
                            rotate_mode_active = False

            elif (
                event.type == pygame.MOUSEBUTTONUP
                and not game_over
                and not level_complete
                and not show_daily_reward_modal
            ):
                if dragging and selected_block_idx is not None:
                    dragging = False
                    shape_data = current_blocks[selected_block_idx]

                    grid_col = round((block_x - BASE_OFFSET_X) / (CELL_SIZE + GAP))
                    grid_row = round((block_y - BASE_OFFSET_Y) / (CELL_SIZE + GAP))

                    if can_place(shape_data[0], grid_col, grid_row):
                        place_block(shape_data, grid_col, grid_row)
                        stype = shape_data[2]

                        if stype == "bomb":
                            trigger_bomb_explosion(grid_col, grid_row)
                        elif stype == "laser":
                            trigger_laser_clearing(grid_col, grid_row)
                        elif stype == "magnet":
                            trigger_magnet_clearing(shape_data[1])
                        else:
                            score += len(shape_data[0]) * 10
                            play_sound_safe(snd_place)

                        is_zeit = GAME_MODES[current_mode_idx] == "ZEIT"
                        if is_zeit:
                            if score > highscore_zeit:
                                highscore_zeit = score
                        else:
                            if score > highscore:
                                highscore = score

                        save_game_data(highscore, highscore_zeit, coins, last_daily_date)

                        clear_lines()
                        current_blocks[selected_block_idx] = None

                        if all(b is None for b in current_blocks):
                            current_blocks = [generate_random_block() for _ in range(3)]

                        if check_game_over() and not level_complete:
                            game_over = True
                            play_sound_safe(snd_gameover)

                    selected_block_idx = None

            elif (
                event.type == pygame.MOUSEMOTION
                and not game_over
                and not level_complete
                and not show_daily_reward_modal
            ):
                if dragging and selected_block_idx is not None:
                    mx, my = event.pos
                    w, h = get_shape_dimensions(current_blocks[selected_block_idx][0])
                    block_x = mx - (w * CELL_SIZE) // 2
                    block_y = my - (h * CELL_SIZE) - 90

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())