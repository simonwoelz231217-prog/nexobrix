import asyncio
import datetime
import json
import math
import os
import random
import struct
import sys
import pygame

# Pygame & Audio initialisieren
pygame.init()
pygame.font.init()

try:
    pygame.mixer.init(frequency=44100, size=-16, channels=1)
    AUDIO_AVAILABLE = True
except Exception:
    AUDIO_AVAILABLE = False


# Prozedurale Sounds generieren
def create_sound(freq, duration, wave_type="sine", volume=0.3):
    if not AUDIO_AVAILABLE:
        return None
    sample_rate = 44100
    n_samples = int(sample_rate * duration)
    buf = bytearray()
    for i in range(n_samples):
        t = i / sample_rate
        decay = 1.0 - (i / n_samples)
        if wave_type == "sine":
            val = math.sin(2 * math.pi * freq * t)
        elif wave_type == "square":
            val = 0.5 if math.sin(2 * math.pi * freq * t) > 0 else -0.5
        scaled = int(32767 * val * decay * volume)
        buf.extend(struct.pack("<h", max(-32768, min(32767, scaled))))
    return pygame.mixer.Sound(bytes(buf))


snd_place = create_sound(350, 0.08, "sine", 0.25)
snd_clear = create_sound(700, 0.2, "sine", 0.4)
snd_combo = create_sound(1050, 0.35, "square", 0.3)
snd_levelup = create_sound(880, 0.4, "sine", 0.5)
snd_bomb = create_sound(120, 0.45, "square", 0.5)
snd_gameover = create_sound(180, 0.5, "square", 0.4)

# Ultra-Tall Smartphone-Format (1280px Höhe)
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 1280
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("NexoBrix")

clock = pygame.time.Clock()

# Schriftarten
font_score = pygame.font.SysFont("Arial", 18, bold=True)
font_title = pygame.font.SysFont("Arial", 24, bold=True)
font_combo = pygame.font.SysFont("Impact", 54, italic=True)
font_float = pygame.font.SysFont("Arial", 26, bold=True)
font_modal = pygame.font.SysFont("Arial", 38, bold=True)
font_btn = pygame.font.SysFont("Arial", 18, bold=True)

# Perfekt skaliertes Raster (8x8 Felder)
GRID_SIZE = 8
CELL_SIZE = 58
GAP = 6
BASE_OFFSET_X = 47
BASE_OFFSET_Y = 170

# Themes
THEMES = [
    {
        "name": "Level Style 1",
        "bg": (20, 24, 40),
        "grid_empty": (30, 36, 58),
        "filled": (255, 140, 0),
        "text": (255, 255, 255),
        "card_bg": (32, 38, 60),
        "obstacle": (90, 100, 120),
    },
    {
        "name": "Level Style 2",
        "bg": (20, 24, 40),
        "grid_empty": (26, 32, 56),
        "filled": (0, 230, 255),
        "text": (200, 255, 255),
        "card_bg": (22, 28, 48),
        "obstacle": (80, 85, 110),
    },
    {
        "name": "Level Style 3",
        "bg": (20, 24, 40),
        "grid_empty": (52, 32, 58),
        "filled": (255, 100, 70),
        "text": (255, 235, 220),
        "card_bg": (46, 26, 50),
        "obstacle": (110, 80, 95),
    },
    {
        "name": "Level Style 4",
        "bg": (20, 24, 40),
        "grid_empty": (28, 48, 44),
        "filled": (46, 213, 115),
        "text": (220, 255, 240),
        "card_bg": (24, 42, 38),
        "obstacle": (80, 105, 100),
    },
    {
        "name": "Level Style 5",
        "bg": (20, 24, 40),
        "grid_empty": (38, 25, 62),
        "filled": (186, 85, 211),
        "text": (245, 230, 255),
        "card_bg": (34, 20, 56),
        "obstacle": (95, 75, 120),
    },
]
current_theme_idx = 0

DIFFICULTIES = ["Einfach", "Normal", "Schwer"]
current_diff_idx = 1

BLOCK_COLORS = [
    (255, 70, 70),    # Rot
    (46, 204, 113),   # Grün
    (52, 152, 219),   # Blau
    (241, 196, 15),   # Gelb
    (155, 89, 182),   # Violett
    (230, 126, 34),   # Orange
    (0, 210, 235),    # Cyan
]

BASE_SHAPES = [
    ([(0, 0)], "normal"),
    ([(0, 0), (1, 0)], "normal"),
    ([(0, 0), (0, 1)], "normal"),
    ([(0, 0), (1, 0), (2, 0)], "normal"),
    ([(0, 0), (0, 1), (0, 2)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (3, 0)], "normal"),
    ([(0, 0), (0, 1), (0, 2), (0, 3)], "normal"),
    ([(0, 0), (1, 0), (0, 1), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (0, 2), (1, 2), (2, 2)], "normal"),
    ([(0, 0), (0, 1), (0, 2), (1, 2)], "normal"),
    ([(1, 0), (1, 1), (1, 2), (0, 2)], "normal"),
    ([(0, 0), (1, 0), (2, 0), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (1, 1), (2, 1)], "normal"),
    ([(1, 0), (2, 0), (0, 1), (1, 1)], "normal"),
    ([(0, 0), (1, 0), (0, 1)], "normal"),
]

COMBO_ANNOUNCEMENTS = ["GOOD!", "GREAT!", "SMOOTH!", "UNSTOPPABLE!", "LEGENDARY!"]


def generate_random_block():
    shape, stype = random.choice(BASE_SHAPES)
    color = random.choice(BLOCK_COLORS)
    return (shape, color, stype)


def rotate_shape_data(shape_data):
    shape, color, stype = shape_data
    rotated = [(-y, x) for x, y in shape]
    min_x = min(x for x, y in rotated)
    min_y = min(y for x, y in rotated)
    normalized = [(x - min_x, y - min_y) for x, y in rotated]
    return (normalized, color, stype)


def get_shape_dimensions(shape):
    max_x = max(x for x, y in shape) + 1
    max_y = max(y for x, y in shape) + 1
    return max_x, max_y


# Permanenter Speicher
def load_game_data():
    hs, c, ld = 0, 150, ""
    if sys.platform == "emscripten":
        try:
            import platform

            val = platform.window.localStorage.getItem("block_puzzle_save")
            if val:
                data = json.loads(str(val))
                hs = data.get("highscore", 0)
                c = data.get("coins", 150)
                ld = data.get("last_daily", "")
                return hs, c, ld
        except Exception:
            pass

    if os.path.exists("highscore.json"):
        try:
            with open("highscore.json", "r") as f:
                data = json.load(f)
                hs = data.get("highscore", 0)
                c = data.get("coins", 150)
                ld = data.get("last_daily", "")
        except Exception:
            pass
    return hs, c, ld


def save_game_data(hs, c, ld):
    payload = {"highscore": hs, "coins": c, "last_daily": ld}
    if sys.platform == "emscripten":
        try:
            import platform

            platform.window.localStorage.setItem(
                "block_puzzle_save", json.dumps(payload)
            )
        except Exception:
            pass
    try:
        with open("highscore.json", "w") as f:
            json.dump(payload, f)
    except Exception:
        pass


# Spiel-Zustand
grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
score = 0
highscore, coins, last_daily_date = load_game_data()
level = 1
level_target = 500

game_over = False
level_complete = False

today_str = datetime.date.today().isoformat()
show_daily_reward_modal = last_daily_date != today_str

particles = []
floating_texts = []
clearing_beams = []

combo_announcement = None
shake_intensity = 0

# Slot-Karten unten
SLOT_RECTS = [
    pygame.Rect(20, 710, 175, 175),
    pygame.Rect(212, 710, 175, 175),
    pygame.Rect(405, 710, 175, 175),
]
current_blocks = [generate_random_block() for _ in range(3)]

selected_block_idx = None
block_x, block_y = 0, 0
dragging = False
rotate_mode_active = False

diff_button_rect = pygame.Rect(BASE_OFFSET_X + 340, 38, 120, 36)
claim_daily_btn_rect = pygame.Rect(180, 620, 240, 60)
next_level_button_rect = pygame.Rect(180, 610, 240, 60)
restart_button_rect = pygame.Rect(180, 610, 240, 60)

# Booster-Buttons im unteren Bereich
btn_rotate_rect = pygame.Rect(20, 920, 128, 130)
btn_clear_rows_rect = pygame.Rect(160, 920, 128, 130)
btn_buy_tnt_rect = pygame.Rect(300, 920, 128, 130)
btn_buy_laser_rect = pygame.Rect(440, 920, 128, 130)


def generate_level_obstacles():
    global grid
    if level < 2 or level % 3 != 0:
        return

    obstacle_count = min(8, (level // 3) * 2 + 1)
    if current_diff_idx == 0:
        obstacle_count = max(1, obstacle_count // 2)
    elif current_diff_idx == 2:
        obstacle_count = int(obstacle_count * 1.5)

    placed = 0
    while placed < obstacle_count:
        r = random.randint(1, GRID_SIZE - 2)
        c = random.randint(1, GRID_SIZE - 2)
        if grid[r][c] is None:
            grid[r][c] = ((90, 100, 120), "obstacle")
            placed += 1


def reset_game():
    global grid, score, level, level_target, current_blocks, game_over, level_complete
    global selected_block_idx, dragging, particles, floating_texts, shake_intensity, rotate_mode_active, current_theme_idx
    grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
    score = 0
    level = 1
    current_theme_idx = 0

    level_target = (
        500 if current_diff_idx == 0 else (600 if current_diff_idx == 1 else 800)
    )
    particles = []
    floating_texts = []
    shake_intensity = 0
    rotate_mode_active = False
    current_blocks = [generate_random_block() for _ in range(3)]
    generate_level_obstacles()
    game_over = False
    level_complete = False
    selected_block_idx = None
    dragging = False


def start_next_level():
    global grid, level, level_target, current_blocks, level_complete, particles, floating_texts, coins, rotate_mode_active, current_theme_idx
    level += 1
    level_target += level * 500
    coins += 100
    save_game_data(highscore, coins, last_daily_date)

    current_theme_idx = (level - 1) % len(THEMES)

    grid = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
    particles = []
    floating_texts = []
    rotate_mode_active = False
    current_blocks = [generate_random_block() for _ in range(3)]
    generate_level_obstacles()
    level_complete = False


def claim_daily_reward():
    global coins, last_daily_date, show_daily_reward_modal
    coins += 200
    last_daily_date = today_str
    save_game_data(highscore, coins, last_daily_date)
    show_daily_reward_modal = False
    add_floating_text(
        "+200 Coins Tages-Bonus!", SCREEN_WIDTH // 2, 550, (245, 166, 35)
    )


def toggle_rotate_mode():
    global rotate_mode_active, coins
    if coins < 50:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 680, (255, 70, 70))
        rotate_mode_active = False
        return

    rotate_mode_active = not rotate_mode_active
    if rotate_mode_active:
        add_floating_text(
            "Tippe auf einen Block!", SCREEN_WIDTH // 2, 680, (41, 128, 185)
        )


def execute_single_block_rotation(idx):
    global coins, current_blocks, rotate_mode_active
    if current_blocks[idx] is None:
        return

    coins -= 50
    save_game_data(highscore, coins, last_daily_date)
    current_blocks[idx] = rotate_shape_data(current_blocks[idx])
    rotate_mode_active = False

    slot_r = SLOT_RECTS[idx]
    add_floating_text("GEDREHT!", slot_r.centerx, slot_r.top - 15, (41, 128, 185))
    if snd_place:
        snd_place.play()


def booster_clear_2_rows():
    global coins, score, shake_intensity, rotate_mode_active
    rotate_mode_active = False

    if coins < 100:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 680, (255, 70, 70))
        return

    row_counts = [
        (r, sum(1 for c in range(GRID_SIZE) if grid[r][c] is not None))
        for r in range(GRID_SIZE)
    ]
    row_counts = [x for x in row_counts if x[1] > 0]

    if not row_counts:
        add_floating_text("Spielfeld ist leer!", SCREEN_WIDTH // 2, 680, (255, 180, 0))
        return

    coins -= 100
    save_game_data(highscore, coins, last_daily_date)

    row_counts.sort(key=lambda x: x[1], reverse=True)
    rows_to_clear = [r for r, count in row_counts[:2]]

    for r in rows_to_clear:
        add_clearing_beam('row', r)
        for c in range(GRID_SIZE):
            if grid[r][c] is not None:
                grid[r][c] = None
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=12)

    shake_intensity = 12
    score += 200
    trigger_combo_announcement("BOOSTER!", (255, 180, 0))

    if snd_combo:
        snd_combo.play()


def buy_special_block(stype, cost):
    global coins, current_blocks, rotate_mode_active
    rotate_mode_active = False

    if coins < cost:
        add_floating_text("Zu wenig Coins!", SCREEN_WIDTH // 2, 680, (255, 70, 70))
        return

    free_idx = None
    for i in range(3):
        if current_blocks[i] is None:
            free_idx = i
            break

    if free_idx is None:
        free_idx = 0

    coins -= cost
    save_game_data(highscore, coins, last_daily_date)

    if stype == "bomb":
        current_blocks[free_idx] = ([(0, 0)], (255, 50, 50), "bomb")
        add_floating_text("TNT GEKAUFT!", SCREEN_WIDTH // 2, 680, (255, 60, 60))
    elif stype == "laser":
        current_blocks[free_idx] = ([(0, 0)], (0, 200, 240), "laser")
        add_floating_text("LASER GEKAUFT!", SCREEN_WIDTH // 2, 680, (0, 200, 240))

    if snd_place:
        snd_place.play()


def add_floating_text(text, x, y, color):
    floating_texts.append(
        {"text": text, "x": x, "y": y, "color": color, "lifetime": 45}
    )


def trigger_combo_announcement(text, color=(255, 215, 0)):
    global combo_announcement
    combo_announcement = {
        "text": text,
        "color": color,
        "scale": 0.2,
        "lifetime": 50,
    }


def add_clearing_beam(btype, index, color=(255, 220, 100)):
    clearing_beams.append(
        {"type": btype, "index": index, "color": color, "lifetime": 14, "max_life": 14}
    )


def update_and_draw_effects(offset_x, offset_y):
    global combo_announcement

    for beam in clearing_beams[:]:
        beam["lifetime"] -= 1
        if beam["lifetime"] <= 0:
            clearing_beams.remove(beam)
        else:
            progress = beam["lifetime"] / beam["max_life"]
            alpha = int(255 * progress)
            surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)

            if beam["type"] == "row":
                r = beam["index"]
                y = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + offset_y - 2
                rect = (BASE_OFFSET_X - 10, y, GRID_SIZE * (CELL_SIZE + GAP) + 16, CELL_SIZE + 4)
            else:
                c = beam["index"]
                x = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + offset_x - 2
                rect = (x, BASE_OFFSET_Y - 10, CELL_SIZE + 4, GRID_SIZE * (CELL_SIZE + GAP) + 16)

            pygame.draw.rect(surf, (*beam["color"], alpha), rect, border_radius=8)
            pygame.draw.rect(surf, (255, 255, 255, alpha), rect, width=3, border_radius=8)
            screen.blit(surf, (0, 0))

    for p in particles[:]:
        p["x"] += p["vx"]
        p["y"] += p["vy"]
        p["radius"] = max(0, p["radius"] - 0.22)
        p["lifetime"] -= 1

        if p["lifetime"] <= 0 or p["radius"] <= 0:
            particles.remove(p)
        else:
            pygame.draw.circle(
                screen,
                p["color"],
                (int(p["x"] + offset_x), int(p["y"] + offset_y)),
                int(p["radius"]),
            )

    for ft in floating_texts[:]:
        ft["y"] -= 1.2
        ft["lifetime"] -= 1

        if ft["lifetime"] <= 0:
            floating_texts.remove(ft)
        else:
            txt_surf = font_float.render(ft["text"], True, ft["color"])
            screen.blit(
                txt_surf,
                (
                    ft["x"] + offset_x - txt_surf.get_width() // 2,
                    ft["y"] + offset_y,
                ),
            )

    if combo_announcement:
        ca = combo_announcement
        ca["lifetime"] -= 1
        if ca["scale"] < 1.0:
            ca["scale"] += 0.12

        if ca["lifetime"] <= 0:
            combo_announcement = None
        else:
            raw_txt = font_combo.render(ca["text"], True, ca["color"])
            scaled_w = int(raw_txt.get_width() * ca["scale"])
            scaled_h = int(raw_txt.get_height() * ca["scale"])
            if scaled_w > 0 and scaled_h > 0:
                txt_surf = pygame.transform.smoothscale(raw_txt, (scaled_w, scaled_h))
                glow_txt = font_combo.render(ca["text"], True, (255, 255, 255))
                glow_surf = pygame.transform.smoothscale(glow_txt, (scaled_w + 6, scaled_h + 6))

                cx = SCREEN_WIDTH // 2
                cy = 135
                screen.blit(glow_surf, (cx - glow_surf.get_width() // 2, cy - glow_surf.get_height() // 2))
                screen.blit(txt_surf, (cx - txt_surf.get_width() // 2, cy - txt_surf.get_height() // 2))


def spawn_particles(x, y, count=12, custom_colors=None):
    colors = custom_colors or [
        (255, 215, 0),
        (255, 100, 50),
        (255, 255, 255),
        (0, 230, 255),
    ]
    for _ in range(count):
        particles.append(
            {
                "x": x,
                "y": y,
                "vx": random.uniform(-7, 7),
                "vy": random.uniform(-7, 7),
                "radius": random.randint(4, 8),
                "lifetime": random.randint(18, 32),
                "color": random.choice(colors),
            }
        )


def draw_beveled_block(surface, x, y, size, color, stype="normal"):
    if stype == "obstacle":
        base_color = (90, 100, 120)
        hi_color = (140, 150, 170)
        sh_color = (50, 55, 70)
    elif stype == "bomb":
        base_color = (230, 50, 50)
        hi_color = (255, 130, 130)
        sh_color = (130, 20, 20)
    elif stype == "laser":
        base_color = (0, 200, 240)
        hi_color = (180, 245, 255)
        sh_color = (0, 100, 140)
    else:
        base_color = color
        hi_color = (
            min(255, color[0] + 70),
            min(255, color[1] + 70),
            min(255, color[2] + 70),
        )
        sh_color = (
            max(0, color[0] - 70),
            max(0, color[1] - 70),
            max(0, color[2] - 70),
        )

    rect = pygame.Rect(x, y, size, size)
    pygame.draw.rect(surface, base_color, rect, border_radius=8)

    pygame.draw.line(surface, hi_color, (x + 3, y + 3), (x + size - 4, y + 3), 3)
    pygame.draw.line(surface, hi_color, (x + 3, y + 3), (x + 3, y + size - 4), 3)

    pygame.draw.line(surface, sh_color, (x + 3, y + size - 3), (x + size - 3, y + size - 3), 3)
    pygame.draw.line(surface, sh_color, (x + size - 3, y + 3), (x + size - 3, y + size - 3), 3)

    if stype == "bomb":
        txt = font_score.render("TNT", True, (255, 255, 255))
        surface.blit(txt, (x + size // 2 - txt.get_width() // 2, y + size // 2 - txt.get_height() // 2))
    elif stype == "laser":
        txt = font_score.render("⚡", True, (255, 255, 255))
        surface.blit(txt, (x + size // 2 - txt.get_width() // 2, y + size // 2 - txt.get_height() // 2))


def draw_grid(offset_x, offset_y):
    theme = THEMES[current_theme_idx]

    # Header Card
    card_rect = pygame.Rect(BASE_OFFSET_X + offset_x - 10, 25 + offset_y, 526, 100)
    pygame.draw.rect(screen, theme["card_bg"], card_rect, border_radius=18)

    lvl_txt = font_title.render(f"LEVEL {level}", True, theme["filled"])
    screen.blit(lvl_txt, (BASE_OFFSET_X + offset_x + 12, 35 + offset_y))

    pygame.draw.circle(
        screen, (245, 166, 35), (BASE_OFFSET_X + offset_x + 175, 50 + offset_y), 12
    )
    pygame.draw.circle(
        screen, (255, 215, 0), (BASE_OFFSET_X + offset_x + 175, 50 + offset_y), 8
    )
    coin_txt = font_title.render(f"{coins}", True, (245, 166, 35))
    screen.blit(coin_txt, (BASE_OFFSET_X + offset_x + 196, 35 + offset_y))

    pygame.draw.rect(screen, (52, 152, 219), diff_button_rect, border_radius=10)
    btn_df_txt = font_score.render(
        DIFFICULTIES[current_diff_idx], True, (255, 255, 255)
    )
    screen.blit(
        btn_df_txt,
        (
            diff_button_rect.centerx - btn_df_txt.get_width() // 2,
            diff_button_rect.centery - btn_df_txt.get_height() // 2,
        ),
    )

    sc_txt = font_score.render(
        f"Punkte: {score} / {level_target}   |   Rekord: {highscore}",
        True,
        theme["text"],
    )
    screen.blit(sc_txt, (BASE_OFFSET_X + offset_x + 12, 80 + offset_y))

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            x = BASE_OFFSET_X + col * (CELL_SIZE + GAP) + offset_x
            y = BASE_OFFSET_Y + row * (CELL_SIZE + GAP) + offset_y

            cell_val = grid[row][col]
            if cell_val is None:
                pygame.draw.rect(
                    screen, theme["grid_empty"], (x, y, CELL_SIZE, CELL_SIZE), border_radius=8
                )
            else:
                color, stype = cell_val
                draw_beveled_block(screen, x, y, CELL_SIZE, color, stype)


def draw_slot_cards(offset_x, offset_y):
    theme = THEMES[current_theme_idx]
    for idx, slot_rect in enumerate(SLOT_RECTS):
        r = slot_rect.move(offset_x, offset_y)
        pygame.draw.rect(screen, theme["card_bg"], r, border_radius=18)

        if rotate_mode_active and current_blocks[idx] is not None:
            pygame.draw.rect(screen, (46, 204, 113), r, width=3, border_radius=18)

        shape_data = current_blocks[idx]
        if shape_data is not None and idx != selected_block_idx:
            w, h = get_shape_dimensions(shape_data[0])
            block_w_px = w * (CELL_SIZE * 0.65 + GAP * 0.65)
            block_h_px = h * (CELL_SIZE * 0.65 + GAP * 0.65)

            center_x = r.centerx - block_w_px // 2
            center_y = r.centery - block_h_px // 2
            draw_block(shape_data, center_x, center_y, scale=0.65)

            if random.random() < 0.08:
                spawn_particles(
                    random.randint(r.left + 10, r.right - 10),
                    random.randint(r.top + 10, r.bottom - 10),
                    count=1,
                    custom_colors=[(255, 255, 255), (255, 215, 0)],
                )


def draw_coin_price(amount, center_x, top_y):
    pygame.draw.circle(screen, (245, 166, 35), (center_x - 18, top_y + 10), 8)
    pygame.draw.circle(screen, (255, 215, 0), (center_x - 18, top_y + 10), 5)
    c_txt = font_score.render(str(amount), True, (245, 166, 35))
    screen.blit(c_txt, (center_x - 6, top_y))


def draw_booster_buttons():
    btn_color = (46, 204, 113) if rotate_mode_active else (41, 128, 185)

    pygame.draw.rect(screen, btn_color, btn_rotate_rect, border_radius=16)
    txt1 = font_btn.render(
        "Wählen..." if rotate_mode_active else "Drehen", True, (255, 255, 255)
    )
    screen.blit(
        txt1,
        (
            btn_rotate_rect.centerx - txt1.get_width() // 2,
            btn_rotate_rect.top + 28,
        ),
    )
    draw_coin_price(50, btn_rotate_rect.centerx, btn_rotate_rect.top + 72)

    pygame.draw.rect(screen, (142, 68, 173), btn_clear_rows_rect, border_radius=16)
    txt2 = font_btn.render("2 Reihen", True, (255, 255, 255))
    screen.blit(
        txt2,
        (
            btn_clear_rows_rect.centerx - txt2.get_width() // 2,
            btn_clear_rows_rect.top + 28,
        ),
    )
    draw_coin_price(100, btn_clear_rows_rect.centerx, btn_clear_rows_rect.top + 72)

    pygame.draw.rect(screen, (231, 76, 60), btn_buy_tnt_rect, border_radius=16)
    txt3 = font_btn.render("💣 TNT", True, (255, 255, 255))
    screen.blit(
        txt3,
        (
            btn_buy_tnt_rect.centerx - txt3.get_width() // 2,
            btn_buy_tnt_rect.top + 28,
        ),
    )
    draw_coin_price(120, btn_buy_tnt_rect.centerx, btn_buy_tnt_rect.top + 72)

    pygame.draw.rect(screen, (0, 180, 220), btn_buy_laser_rect, border_radius=16)
    txt4 = font_btn.render("⚡ Laser", True, (255, 255, 255))
    screen.blit(
        txt4,
        (
            btn_buy_laser_rect.centerx - txt4.get_width() // 2,
            btn_buy_laser_rect.top + 28,
        ),
    )
    draw_coin_price(120, btn_buy_laser_rect.centerx, btn_buy_laser_rect.top + 72)


def draw_ghost_preview(shape, grid_col, grid_row, offset_x, offset_y):
    if not can_place(shape, grid_col, grid_row):
        return

    ghost_surface = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
    pygame.draw.rect(
        ghost_surface, (255, 255, 255, 90), (0, 0, CELL_SIZE, CELL_SIZE), border_radius=8
    )

    for bx, by in shape:
        c, r = grid_col + bx, grid_row + by
        if 0 <= c < GRID_SIZE and 0 <= r < GRID_SIZE:
            gx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + offset_x
            gy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + offset_y
            screen.blit(ghost_surface, (gx, gy))


def draw_block(shape_data, pos_x, pos_y, scale=1.0):
    shape, color, stype = shape_data
    size = int(CELL_SIZE * scale)
    gap = int(GAP * scale)

    for bx, by in shape:
        x = pos_x + bx * (size + gap)
        y = pos_y + by * (size + gap)
        draw_beveled_block(screen, x, y, size, color, stype)


def can_place(shape, grid_col, grid_row):
    for bx, by in shape:
        c, r = grid_col + bx, grid_row + by
        if c < 0 or c >= GRID_SIZE or r < 0 or r >= GRID_SIZE:
            return False
        if grid[r][c] is not None:
            return False
    return True


def place_block(shape_data, grid_col, grid_row):
    shape, color, stype = shape_data
    for bx, by in shape:
        grid[grid_row + by][grid_col + bx] = (color, stype)


def trigger_bomb_explosion(center_col, center_row):
    global score, shake_intensity
    cleared_count = 0
    explosion_colors = [(255, 60, 60), (255, 200, 0), (255, 255, 255)]

    for r in range(center_row - 1, center_row + 2):
        for c in range(center_col - 1, center_col + 2):
            if 0 <= r < GRID_SIZE and 0 <= c < GRID_SIZE:
                if grid[r][c] is not None:
                    grid[r][c] = None
                    cleared_count += 1
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=12, custom_colors=explosion_colors)

    score_gained = cleared_count * 50 + 200
    score += score_gained
    shake_intensity = 18
    center_x = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
    center_y = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP)
    add_floating_text(f"BOOM! +{score_gained}", center_x, center_y, (255, 80, 80))
    if snd_bomb:
        snd_bomb.play()


def trigger_laser_clearing(center_col, center_row):
    global score, shake_intensity
    laser_colors = [(0, 200, 240), (255, 255, 255)]

    add_clearing_beam('row', center_row, (0, 200, 240))
    add_clearing_beam('col', center_col, (0, 200, 240))

    for c in range(GRID_SIZE):
        grid[center_row][c] = None
        cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
        cy = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP) + CELL_SIZE // 2
        spawn_particles(cx, cy, count=8, custom_colors=laser_colors)

    for r in range(GRID_SIZE):
        grid[r][center_col] = None
        cx = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
        cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
        spawn_particles(cx, cy, count=8, custom_colors=laser_colors)

    score += 350
    shake_intensity = 14
    center_x = BASE_OFFSET_X + center_col * (CELL_SIZE + GAP) + CELL_SIZE // 2
    center_y = BASE_OFFSET_Y + center_row * (CELL_SIZE + GAP)
    add_floating_text("LASER! +350", center_x, center_y, (0, 200, 240))
    if snd_combo:
        snd_combo.play()


def clear_lines():
    global score, highscore, coins, shake_intensity, level_complete

    rows = [
        r
        for r in range(GRID_SIZE)
        if all(grid[r][c] is not None for c in range(GRID_SIZE))
    ]
    cols = [
        c
        for c in range(GRID_SIZE)
        if all(grid[r][c] is not None for r in range(GRID_SIZE))
    ]

    cleared = len(rows) + len(cols)
    if cleared > 0:
        pts = cleared * 100 * cleared
        score += pts

        coins_gained = cleared * 15
        coins += coins_gained

        if score > highscore:
            highscore = score

        save_game_data(highscore, coins, last_daily_date)
        shake_intensity = 8 * cleared

        announcement_idx = min(cleared - 1, len(COMBO_ANNOUNCEMENTS) - 1)
        trigger_combo_announcement(COMBO_ANNOUNCEMENTS[announcement_idx])

        if snd_combo and cleared > 1:
            snd_combo.play()
        elif snd_clear:
            snd_clear.play()

    for r in rows:
        add_clearing_beam('row', r)
        for c in range(GRID_SIZE):
            cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
            cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
            spawn_particles(cx, cy, count=10)
            grid[r][c] = None

    for c in cols:
        add_clearing_beam('col', c)
        for r in range(GRID_SIZE):
            if grid[r][c] is not None:
                cx = BASE_OFFSET_X + c * (CELL_SIZE + GAP) + CELL_SIZE // 2
                cy = BASE_OFFSET_Y + r * (CELL_SIZE + GAP) + CELL_SIZE // 2
                spawn_particles(cx, cy, count=10)
                grid[r][c] = None

    if cleared > 0:
        add_floating_text(f"+{pts}", SCREEN_WIDTH // 2, 400, (255, 215, 0))

    if score >= level_target and not level_complete:
        level_complete = True
        if snd_levelup:
            snd_levelup.play()


def check_game_over():
    for shape_data in current_blocks:
        if shape_data is not None:
            shape = shape_data[0]
            for r in range(GRID_SIZE):
                for c in range(GRID_SIZE):
                    if can_place(shape, c, r):
                        return False
    return True


def draw_daily_reward_modal():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((10, 15, 25, 220))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(90, 420, 420, 330)
    pygame.draw.rect(screen, (32, 38, 60), modal_rect, border_radius=16)

    title_txt = font_modal.render("TAGES-BONUS!", True, (245, 166, 35))
    sub_txt = font_title.render("Danke fürs Wiederspielen!", True, (255, 255, 255))
    screen.blit(title_txt, (SCREEN_WIDTH // 2 - title_txt.get_width() // 2, 445))
    screen.blit(sub_txt, (SCREEN_WIDTH // 2 - sub_txt.get_width() // 2, 505))

    pygame.draw.circle(screen, (245, 166, 35), (SCREEN_WIDTH // 2 - 75, 575), 14)
    pygame.draw.circle(screen, (255, 215, 0), (SCREEN_WIDTH // 2 - 75, 575), 9)
    bonus_txt = font_modal.render("+200", True, (46, 204, 113))
    screen.blit(
        bonus_txt, (SCREEN_WIDTH // 2 - 50, 575 - bonus_txt.get_height() // 2)
    )

    pygame.draw.rect(screen, (245, 166, 35), claim_daily_btn_rect, border_radius=25)
    btn_txt = font_title.render("Kassieren! 🎁", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            claim_daily_btn_rect.centerx - btn_txt.get_width() // 2,
            claim_daily_btn_rect.centery - btn_txt.get_height() // 2,
        ),
    )


def draw_level_complete_screen():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((10, 15, 25, 200))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(100, 410, 400, 340)
    pygame.draw.rect(screen, (255, 255, 255), modal_rect, border_radius=16)

    title_txt = font_modal.render("GESCHAFFT!", True, (46, 204, 113))
    sub_txt = font_title.render(f"Level {level} geschafft!", True, (40, 50, 70))
    bonus_txt = font_title.render("Belohnung: +100 Coins", True, (245, 166, 35))
    score_txt = font_score.render(
        f"Gesamtpunkte: {score}",
        True,
        (100, 110, 130),
    )

    screen.blit(title_txt, (SCREEN_WIDTH // 2 - title_txt.get_width() // 2, 435))
    screen.blit(sub_txt, (SCREEN_WIDTH // 2 - sub_txt.get_width() // 2, 495))
    screen.blit(bonus_txt, (SCREEN_WIDTH // 2 - bonus_txt.get_width() // 2, 540))
    screen.blit(score_txt, (SCREEN_WIDTH // 2 - score_txt.get_width() // 2, 580))

    pygame.draw.rect(screen, (46, 204, 113), next_level_button_rect, border_radius=25)
    btn_txt = font_title.render("Nächstes Level ->", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            next_level_button_rect.centerx - btn_txt.get_width() // 2,
            next_level_button_rect.centery - btn_txt.get_height() // 2,
        ),
    )


def draw_game_over_screen():
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((10, 15, 25, 210))
    screen.blit(overlay, (0, 0))

    modal_rect = pygame.Rect(100, 410, 400, 320)
    pygame.draw.rect(screen, (255, 255, 255), modal_rect, border_radius=16)

    go_text = font_modal.render("GAME OVER", True, (231, 76, 60))
    score_txt = font_title.render(f"Erreichtes Level: {level}", True, (40, 50, 70))
    detail_txt = font_score.render(
        f"Punkte: {score}   |   Rekord: {highscore}", True, (100, 110, 130)
    )

    screen.blit(go_text, (SCREEN_WIDTH // 2 - go_text.get_width() // 2, 435))
    screen.blit(score_txt, (SCREEN_WIDTH // 2 - score_txt.get_width() // 2, 495))
    screen.blit(detail_txt, (SCREEN_WIDTH // 2 - detail_txt.get_width() // 2, 545))

    pygame.draw.rect(screen, (231, 76, 60), restart_button_rect, border_radius=25)
    btn_txt = font_title.render("Neustart", True, (255, 255, 255))
    screen.blit(
        btn_txt,
        (
            restart_button_rect.centerx - btn_txt.get_width() // 2,
            restart_button_rect.centery - btn_txt.get_height() // 2,
        ),
    )


# --- Hauptschleife ---
async def main():
    global score, highscore, coins, shake_intensity
    global selected_block_idx, block_x, block_y, dragging, game_over, level_complete
    global current_theme_idx, current_diff_idx, current_blocks, level, rotate_mode_active

    running = True
    while running:
        off_x, off_y = 0, 0
        if shake_intensity > 0:
            off_x = random.randint(-shake_intensity, shake_intensity)
            off_y = random.randint(-shake_intensity, shake_intensity)
            shake_intensity -= 1

        theme = THEMES[current_theme_idx]
        screen.fill(theme["bg"])

        draw_grid(off_x, off_y)
        draw_slot_cards(off_x, off_y)
        draw_booster_buttons()

        if (
            dragging
            and selected_block_idx is not None
            and not game_over
            and not level_complete
            and not show_daily_reward_modal
        ):
            shape = current_blocks[selected_block_idx][0]
            g_col = round((block_x - BASE_OFFSET_X) / (CELL_SIZE + GAP))
            g_row = round((block_y - BASE_OFFSET_Y) / (CELL_SIZE + GAP))
            draw_ghost_preview(shape, g_col, g_row, off_x, off_y)

        if (
            dragging
            and selected_block_idx is not None
            and not game_over
            and not level_complete
            and not show_daily_reward_modal
        ):
            draw_block(current_blocks[selected_block_idx], block_x, block_y, scale=1.0)

        update_and_draw_effects(off_x, off_y)

        if show_daily_reward_modal:
            draw_daily_reward_modal()
        elif level_complete:
            draw_level_complete_screen()
        elif game_over:
            draw_game_over_screen()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    reset_game()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if show_daily_reward_modal:
                    if claim_daily_btn_rect.collidepoint(mx, my):
                        claim_daily_reward()

                elif level_complete and next_level_button_rect.collidepoint(mx, my):
                    start_next_level()

                elif game_over and restart_button_rect.collidepoint(mx, my):
                    reset_game()

                elif not game_over and not level_complete:
                    if diff_button_rect.collidepoint(mx, my):
                        current_diff_idx = (current_diff_idx + 1) % len(DIFFICULTIES)
                        reset_game()

                    elif btn_rotate_rect.collidepoint(mx, my):
                        toggle_rotate_mode()

                    elif btn_clear_rows_rect.collidepoint(mx, my):
                        booster_clear_2_rows()

                    elif btn_buy_tnt_rect.collidepoint(mx, my):
                        buy_special_block("bomb", 120)

                    elif btn_buy_laser_rect.collidepoint(mx, my):
                        buy_special_block("laser", 120)

                    else:
                        slot_clicked = False
                        for idx, slot_rect in enumerate(SLOT_RECTS):
                            if slot_rect.collidepoint(mx, my):
                                if current_blocks[idx] is not None:
                                    slot_clicked = True
                                    if rotate_mode_active:
                                        execute_single_block_rotation(idx)
                                    else:
                                        selected_block_idx = idx
                                        dragging = True
                                        w, h = get_shape_dimensions(
                                            current_blocks[idx][0]
                                        )
                                        block_x = mx - (w * CELL_SIZE) // 2
                                        block_y = my - (h * CELL_SIZE) - 75

                        if not slot_clicked and rotate_mode_active:
                            rotate_mode_active = False

            elif (
                event.type == pygame.MOUSEBUTTONUP
                and not game_over
                and not level_complete
                and not show_daily_reward_modal
            ):
                if dragging and selected_block_idx is not None:
                    dragging = False
                    shape_data = current_blocks[selected_block_idx]

                    grid_col = round((block_x - BASE_OFFSET_X) / (CELL_SIZE + GAP))
                    grid_row = round((block_y - BASE_OFFSET_Y) / (CELL_SIZE + GAP))

                    if can_place(shape_data[0], grid_col, grid_row):
                        place_block(shape_data, grid_col, grid_row)
                        stype = shape_data[2]

                        if stype == "bomb":
                            trigger_bomb_explosion(grid_col, grid_row)
                        elif stype == "laser":
                            trigger_laser_clearing(grid_col, grid_row)
                        else:
                            score += len(shape_data[0]) * 10
                            if snd_place:
                                snd_place.play()

                        if score > highscore:
                            highscore = score
                        save_game_data(highscore, coins, last_daily_date)

                        clear_lines()
                        current_blocks[selected_block_idx] = None

                        if all(b is None for b in current_blocks):
                            current_blocks = [
                                generate_random_block() for _ in range(3)
                            ]

                        if check_game_over() and not level_complete:
                            game_over = True
                            if snd_gameover:
                                snd_gameover.play()

                    selected_block_idx = None

            elif (
                event.type == pygame.MOUSEMOTION
                and not game_over
                and not level_complete
                and not show_daily_reward_modal
            ):
                if dragging and selected_block_idx is not None:
                    mx, my = event.pos
                    w, h = get_shape_dimensions(current_blocks[selected_block_idx][0])
                    block_x = mx - (w * CELL_SIZE) // 2
                    block_y = my - (h * CELL_SIZE) - 75

        pygame.display.flip()
        clock.tick(60)

        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())