import json
import os
import shutil
import subprocess
import sys
import time

ICON_FILENAME = "icon.png"

print("1. Starte Pygbag Build...")
subprocess.run(
    [sys.executable, "-X", "utf8", "-m", "pygbag", "--build", "main.py"]
)

web_dir = os.path.join("build", "web")
html_path = os.path.join(web_dir, "index.html")

# 2. Icon kopieren
icon_src = ICON_FILENAME
if os.path.exists(icon_src):
    shutil.copy(icon_src, os.path.join(web_dir, "favicon.ico"))
    shutil.copy(icon_src, os.path.join(web_dir, "apple-touch-icon.png"))
    shutil.copy(icon_src, os.path.join(web_dir, "icon-192.png"))
    shutil.copy(icon_src, os.path.join(web_dir, "icon-512.png"))
    print("✅ Icons erfolgreich kopiert!")

# 3. Web-App Manifest
manifest_data = {
    "name": "NexoBrix",
    "short_name": "NexoBrix",
    "start_url": f"./?v={int(time.time())}",
    "display": "standalone",
    "background_color": "#141828",
    "theme_color": "#141828",
    "icons": [
        {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
    ],
}

manifest_path = os.path.join(web_dir, "manifest.json")
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest_data, f, indent=4)

# 4. Anti-Cache, CSS-Overrides & JS-Border-Killer in index.html einfügen
if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    meta_tags = f"""
    <!-- Anti-Cache & Border Removal -->
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    
    <style>
        * {{
            outline: none !important;
            border: none !important;
            box-shadow: none !important;
            -webkit-tap-highlight-color: transparent !important;
            -webkit-touch-callout: none !important;
            -webkit-user-select: none !important;
            user-select: none !important;
        }}
        html, body {{
            background-color: #141828 !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            overflow: hidden !important;
            border: 0 !important;
            outline: none !important;
        }}
        canvas, #canvas, .emscripten, div, iframe {{
            border: 0px none transparent !important;
            outline: none !important;
            box-shadow: none !important;
        }}
    </style>
    <link rel="manifest" href="manifest.json?v={int(time.time())}">
    <link rel="icon" href="favicon.ico?v={int(time.time())}" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <meta name="theme-color" content="#141828">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="NexoBrix">
    """

    script_border_fix = """
    <script>
        function removeBorders() {
            document.querySelectorAll('canvas, div, iframe, #canvas, .emscripten').forEach(el => {
                el.style.border = 'none';
                el.style.outline = 'none';
                el.style.boxShadow = 'none';
            });
        }
        window.addEventListener('load', removeBorders);
        setInterval(removeBorders, 300);
    </script>
    """

    if "</head>" in content:
        content = content.replace("</head>", meta_tags + "\n</head>")
    elif "</HEAD>" in content:
        content = content.replace("</HEAD>", meta_tags + "\n</HEAD>")
    else:
        content += meta_tags

    if "</body>" in content:
        content = content.replace("</body>", script_border_fix + "\n</body>")
    elif "</BODY>" in content:
        content = content.replace("</BODY>", script_border_fix + "\n</BODY>")
    else:
        content += script_border_fix

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)

    print("✅ Anti-Cache & Border-Fix erfolgreich injiziert!")
else:
    print("❌ Datei build/web/index.html nicht gefunden.")