import json
import os
import shutil
import subprocess
import sys

ICON_FILENAME = "icon.png"

print("1. Starte Pygbag Build...")
subprocess.run(
    [sys.executable, "-X", "utf8", "-m", "pygbag", "--build", "main.py"]
)

web_dir = os.path.join("build", "web")
html_path = os.path.join(web_dir, "index.html")

# 2. Icon kopieren und als manifest-konforme PNGs ablegen
icon_src = ICON_FILENAME
if os.path.exists(icon_src):
    shutil.copy(icon_src, os.path.join(web_dir, "favicon.ico"))
    shutil.copy(icon_src, os.path.join(web_dir, "apple-touch-icon.png"))
    shutil.copy(icon_src, os.path.join(web_dir, "icon-192.png"))
    shutil.copy(icon_src, os.path.join(web_dir, "icon-512.png"))
    print("✅ NexoBrix-Icons erfolgreich kopiert!")
else:
    print(f"⚠️ Hinweis: '{ICON_FILENAME}' wurde nicht gefunden.")

# 3. Eine echte Web-App Manifest-Datei (manifest.json) erstellen
manifest_data = {
    "name": "NexoBrix",
    "short_name": "NexoBrix",
    "start_url": "./",
    "display": "standalone",
    "background_color": "#141828",
    "theme_color": "#141828",
    "icons": [
        {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
    ],
}

manifest_path = os.path.join(web_dir, "manifest.json")
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest_data, f, indent=4)

# 4. HTML anpassen (Verknüpfung zur manifest.json & Meta-Tags)
if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    meta_tags = """
    <style>
        html, body {
            background-color: #141828 !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            overflow: hidden !important;
        }
    </style>
    <link rel="manifest" href="manifest.json">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <meta name="theme-color" content="#141828">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="NexoBrix">
    """

    if "</head>" in content:
        content = content.replace("</head>", meta_tags + "\n</head>")
    elif "</HEAD>" in content:
        content = content.replace("</HEAD>", meta_tags + "\n</HEAD>")
    else:
        content += meta_tags

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)

    print("✅ Manifest & HTML erfolgreich injiziert!")
else:
    print("❌ Datei build/web/index.html nicht gefunden.")